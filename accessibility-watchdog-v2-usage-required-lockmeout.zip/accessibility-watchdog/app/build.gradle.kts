plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.accessibilitywatchdog"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.accessibilitywatchdog"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "2.1"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// Intentionally NO dependencies block: the app uses only the Android platform APIs.
// (The Kotlin plugin adds the open-source kotlin-stdlib automatically.)
