package com.example.accessibilitywatchdog

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.view.accessibility.AccessibilityManager

/** What the user sees for one installed Accessibility Service. */
data class ServiceEntry(
    val component: ComponentName,
    val appLabel: String,
    val serviceLabel: String
)

/**
 * Lists installed Accessibility Services. Using AccessibilityManager to *list* services does
 * not make this app an Accessibility Service and needs no Accessibility permission.
 */
object ServiceCatalog {

    /**
     * Lock Me Out is a supported built-in target. Some OEM/Android combinations do not expose
     * its Accessibility service through AccessibilityManager.installedAccessibilityServiceList,
     * even though the service can be enabled in Settings. For this app we therefore support a
     * package-wide target: any enabled Accessibility component belonging to this package counts.
     */
    const val LOCK_ME_OUT_PACKAGE = "com.teqtic.lockmeout"
    const val ANY_SERVICE_CLASS = "*"

    fun installed(context: Context): List<ServiceEntry> {
        val pm = context.packageManager
        val manager = context.getSystemService(AccessibilityManager::class.java)
        val entries = manager?.installedAccessibilityServiceList
            ?.mapNotNull { info -> info.resolveInfo?.serviceInfo }
            ?.map { toEntry(pm, it) }
            ?.toMutableList()
            ?: mutableListOf()

        // Add Lock Me Out even when its Accessibility service is missing from the generic
        // AccessibilityManager list. Only show it when the app is actually installed.
        if (isPackageInstalled(pm, LOCK_ME_OUT_PACKAGE)) {
            val appLabel = try {
                pm.getApplicationInfo(LOCK_ME_OUT_PACKAGE, 0).loadLabel(pm).toString()
            } catch (_: PackageManager.NameNotFoundException) {
                "Lock Me Out"
            }
            entries.add(
                ServiceEntry(
                    ComponentName(LOCK_ME_OUT_PACKAGE, ANY_SERVICE_CLASS),
                    appLabel,
                    "Lock Me Out Accessibility"
                )
            )
        }

        return entries
            .distinctBy { it.component }
            .sortedBy { it.appLabel.lowercase() }
    }

    /** Looks up the label of a previously chosen service, including the Lock Me Out package target. */
    fun describe(context: Context, component: ComponentName): ServiceEntry? {
        val pm = context.packageManager
        if (isLockMeOutTarget(component)) {
            if (!isPackageInstalled(pm, LOCK_ME_OUT_PACKAGE)) return null
            val appLabel = try {
                pm.getApplicationInfo(LOCK_ME_OUT_PACKAGE, 0).loadLabel(pm).toString()
            } catch (_: PackageManager.NameNotFoundException) {
                "Lock Me Out"
            }
            return ServiceEntry(
                component,
                appLabel,
                "Lock Me Out Accessibility"
            )
        }

        return try {
            toEntry(pm, pm.getServiceInfo(component, 0))
        } catch (e: PackageManager.NameNotFoundException) {
            null
        }
    }

    fun isLockMeOutTarget(component: ComponentName): Boolean =
        component.packageName == LOCK_ME_OUT_PACKAGE &&
            component.className == ANY_SERVICE_CLASS

    private fun isPackageInstalled(pm: PackageManager, packageName: String): Boolean =
        try {
            pm.getApplicationInfo(packageName, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }

    private fun toEntry(pm: PackageManager, info: ServiceInfo): ServiceEntry {
        val appLabel = info.applicationInfo?.loadLabel(pm)?.toString() ?: info.packageName
        val serviceLabel = info.loadLabel(pm).toString()
        return ServiceEntry(ComponentName(info.packageName, info.name), appLabel, serviceLabel)
    }
}
