# Accessibility Watchdog

A small, open-source Android app that watches **one Accessibility Service that you choose**
(for example Lock Me Out, Curbbox or any other accessibility-based blocker). While that
service is ON the app does nothing. If it is turned OFF, a full-screen warning appears until
you turn the service back on yourself.

* Kotlin, no third-party libraries (Android platform APIs only), no network code.
* The watchdog is **not** an Accessibility Service and **never** changes
  `Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES` or grants itself anything. It only reads.
* No Shizuku, no VPN, no Device Admin, no Device Owner, no root. Installs normally.

> **Honesty note.** Nobody (including the author of this code) can promise that an ordinary
> app is bypass-proof or "virus-free". This repository gives you everything needed to check
> it yourself: full source, a reproducible CI build, the final manifest, the permission list,
> a source audit script and the APK's SHA-256. See *Limitations* below.

## How it works

| Piece | What it does |
|---|---|
| `WatchdogService` | Foreground service. A `ContentObserver` on `ENABLED_ACCESSIBILITY_SERVICES` and `ACCESSIBILITY_ENABLED` fires the moment the setting changes. Also re-checks on screen on, unlock and when you open the app. **No periodic polling while protection is active.** |
| `AccessibilityState` | Read-only check. Parses every entry of the setting as a `ComponentName` (so `pkg/.Cls` and `pkg/pkg.Cls` both match) and also requires `ACCESSIBILITY_ENABLED = 1`. |
| `WarningOverlay` | The full-screen warning (`TYPE_APPLICATION_OVERLAY`). Opaque, labelled "Accessibility Watchdog", no skip / ignore / snooze buttons. |
| `MainActivity` / `PickerActivity` | Status screen and the service picker (app name, service name, package). |
| `BootReceiver` | Restarts monitoring after reboot (once the phone is unlocked) and after an app update. |

### Opening Settings without locking yourself out

An overlay on top of Settings would make it impossible to switch the service on (and Android
Settings ignores touches while an overlay covers its sensitive screens). So:

1. Tap **OPEN ACCESSIBILITY SETTINGS** on the warning. Settings opens and **every** watchdog
   overlay window is removed.
2. The warning comes back **immediately** if you return to the watchdog or the screen turns off.
3. It also comes back the moment you leave Settings, **if you granted the required "Usage
   access"**. Without it the watchdog cannot see which app is on screen, so it uses a
   there is no timer fallback; grant Usage access before using the watchdog.
4. Hard cap: 10 minutes in Settings, then the warning returns anyway.
5. If the service is ON at any point, the warning is removed and nothing else happens.

**Test warning** shows the same screen with a "TEST MODE" banner and an **END TEST** button
(auto-closes after 10 s). It changes no system setting. The real warning has no such button.

## Permissions (every line of the manifest)

| Permission | Why |
|---|---|
| `SYSTEM_ALERT_WINDOW` | Draw the warning above other apps. There is no other normal-app mechanism for this. You grant it in Settings ("Display over other apps"). |
| `FOREGROUND_SERVICE` + `FOREGROUND_SERVICE_SPECIAL_USE` | Keep the watcher process alive so the observer keeps working (Android 14 requires the type-specific permission). |
| `POST_NOTIFICATIONS` | Android 13+: lets the mandatory "watchdog is running" notification be seen, and shows an alert if the overlay permission is missing. |
| `RECEIVE_BOOT_COMPLETED` | Restart monitoring after reboot. |
| `PACKAGE_USAGE_STATS` | **Required for the strongest mode.** It is used only to detect when the user leaves Settings so the warning can immediately return if Accessibility is still OFF. Nothing is stored or sent; the app has no network permission at all. |
| `<queries>` (not a permission) | Lets the app see Accessibility Services and the Settings app on Android 11+ without a broad "list all apps" permission. |

**INTERNET permission is not declared.** Nor any other network permission.

## Limitations (please read)

A normal Android app cannot be made impossible to bypass. Known ways around this watchdog:

* **While Settings is open you can do anything in Settings**, including *Apps → Accessibility
  Watchdog → Force stop / Uninstall* or revoking "Display over other apps". The watchdog must not
  and does not interfere with Settings.
* Force-stopping or uninstalling the app; clearing its data; reboot into safe mode; ADB.
* Revoking the overlay permission (the app then posts a high-priority notification, but cannot block).
* The overlay cannot cover the **status bar / notification shade / quick settings**, and Android
  does not show overlays on the **lock screen**. System dialogs, and some Settings pages, hide
  overlays on purpose.
* Android/OEM battery managers (Xiaomi, Huawei, Samsung, etc.) may kill the service or block
  auto-start. Allow background activity / disable battery optimisation for this app.
* After a **force-stop**, Android will not deliver the boot broadcast until you open the app once.
* Before the first unlock after a reboot the watchdog cannot run (its storage is still locked).
* You can change or clear the monitored service inside the app while protection is ON.
* If the monitored service is **uninstalled**, it counts as OFF; the warning stays until you
  reinstall it. If you ever need an emergency exit: Settings → Apps → Accessibility Watchdog →
  Uninstall (reachable from the Settings button on the warning).
* After a reboot, nothing needs to be re-granted; permissions persist. If the OEM blocks
  auto-start, you may need to open the app once.

## Build it (GitHub Actions)

The workflow is `.github/workflows/build-apk.yml`. It runs the source audit, builds the **debug**
APK with Gradle 8.9 / JDK 17, checks with `aapt2` that `INTERNET` is absent (build fails
otherwise), prints the SHA-256 in the run summary and uploads the APK as an artifact.

### From an Android phone

GitHub's website cannot upload folders or unzip archives from a phone, so the most reliable way
is Termux (install it from **F-Droid**, not the Play Store):

1. On github.com (Chrome → ⋮ → *Desktop site*) create an empty **private** repository, e.g. `accessibility-watchdog`.
2. Create a token: *Settings → Developer settings → Personal access tokens → Fine-grained tokens*,
   limited to that one repository, permission **Contents: Read and write** (and **Workflows: Read and write**
   so the workflow file can be pushed). Copy it.
3. Copy `accessibility-watchdog.zip` to your phone's Download folder, then in Termux:

       pkg update && pkg install -y git unzip
       termux-setup-storage
       cd ~ && unzip ~/storage/downloads/accessibility-watchdog.zip && cd accessibility-watchdog
       git init -b main
       git add -A && git commit -m "Accessibility Watchdog"
       git remote add origin https://github.com/YOUR_USER/accessibility-watchdog.git
       git push -u origin main

   When asked, username = your GitHub name, password = the token.
4. Pushing to `main` starts the build automatically. To run it by hand: repository → **Actions** →
   *Build debug APK* → **Run workflow**.
5. When the run turns green, open it. The **SHA-256** and permission list are in the *Summary*.
   Under **Artifacts** tap `accessibility-watchdog-debug` (a zip is downloaded).
6. Unzip it (Files by Google / ZArchiver) and compare the hash:
   `sha256sum accessibility-watchdog-debug.apk` in Termux must equal the one in the summary.
7. Tap `accessibility-watchdog-debug.apk`, allow "Install unknown apps" for the app you opened it with,
   and install. Play Protect may warn about an unknown debug app; that is expected for a self-built APK.
8. Open the app → *Choose service to monitor* → pick your blocker → allow "Display over other apps"
   (and notifications; "Usage access" is optional) → tap **Test warning**.

### On a computer

    gradle :app:assembleDebug     # Gradle 8.9+, JDK 17, Android SDK platform 34
    # APK: app/build/outputs/apk/debug/app-debug.apk

(No Gradle wrapper is committed. Run `gradle wrapper` once if you want one.)

Debug APKs are signed with a throw-away key generated on each CI run, so a newer build cannot be
installed over an older one: uninstall the old one first. The artifact is kept 30 days.

## Verify it yourself

    bash scripts/audit.sh                                   # source audit table, exit 1 on failure
    aapt2 dump permissions accessibility-watchdog-debug.apk # INTERNET must not appear
    sha256sum accessibility-watchdog-debug.apk
