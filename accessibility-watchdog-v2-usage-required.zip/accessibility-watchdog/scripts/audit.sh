#!/usr/bin/env bash
# Source audit for Accessibility Watchdog. Prints a table and exits non-zero if anything that
# must be absent is found. Run from the repository root:  bash scripts/audit.sh
set -u
cd "$(dirname "$0")/.."

SCAN=(app build.gradle.kts settings.gradle.kts gradle.properties)
MANIFEST=app/src/main/AndroidManifest.xml
fail=0

echo "| Item | Found? | Explanation |"
echo "|---|---|---|"

# check "<label>" "<regex>" "<explanation when absent>"
# Fails the audit if the regex matches anything in the scanned files.
check() {
  local label="$1" regex="$2" ok_note="$3" hits
  hits=$(grep -rniE --exclude-dir=build -e "$regex" "${SCAN[@]}" 2>/dev/null \
         | grep -v 'schemas.android.com' || true)
  if [ -z "$hits" ]; then
    echo "| $label | No | $ok_note |"
  else
    fail=1
    local first
    first=$(echo "$hits" | head -n 3 | tr '\n' ' ' | sed 's/|/\\|/g')
    echo "| $label | **YES** | Matches: $first |"
  fi
}

check "INTERNET permission (and other network permissions)" \
  'permission\.(INTERNET|ACCESS_NETWORK_STATE|ACCESS_WIFI_STATE|CHANGE_NETWORK_STATE|NEARBY_WIFI_DEVICES)' \
  "Not declared anywhere in the manifest."
check "Network libraries" \
  'okhttp|retrofit|volley|ktor|apache\.http|HttpURLConnection|HttpsURLConnection|URLConnection|java\.net\.|javax\.net|WebView|DownloadManager|ConnectivityManager|grpc' \
  "No networking classes or libraries are imported or used."
check "HTTP (http://)" 'http://' \
  "No http:// URL in the code (only the XML namespace URL schemas.android.com, which is not a network call, is ignored)."
check "HTTPS (https://)" 'https://' "No https:// URL anywhere in the code."
check "Sockets" 'Socket|ServerSocket|DatagramSocket|SocketChannel' "No socket classes used."
check "Telemetry / crash reporting" \
  'telemetry|crashlytics|sentry|bugsnag|appcenter|acra|instabug' "No telemetry or crash-reporting code."
check "Analytics" \
  'analytics|mixpanel|amplitude|segment\.io|flurry|matomo|posthog|appsflyer|adjust\.com' "No analytics code."
check "Firebase / Google services" \
  'firebase|google-services|com\.google\.gms|play-services|gms\.' "No Firebase or Play Services dependency."
check "Advertising SDKs" \
  'admob|applovin|ironsource|mopub|vungle|chartboost|unityads|startapp|AdvertisingId|\.ads\.' "No ad SDK or advertising ID."
check "Tracking / device identifiers" \
  'tracker|fingerprint|ANDROID_ID|getImei|getDeviceId|getSubscriberId|InstallReferrer|READ_PHONE_STATE|ACCESS_FINE_LOCATION|ACCESS_COARSE_LOCATION|READ_CONTACTS' \
  "No identifiers, location, contacts or phone-state access."
check "Remote configuration" 'remote.?config|RemoteConfig|feature.?flag|launchdarkly' "No remote configuration."
check "Dynamic code loading / downloads" \
  'DexClassLoader|PathClassLoader|InMemoryDexClassLoader|System\.load|loadLibrary|Class\.forName|getDeclaredMethod|Runtime\.getRuntime|ProcessBuilder|dalvik\.system' \
  "No dynamic class loading, native loading, reflection or process execution."
check "Obfuscated code / minification" \
  'isMinifyEnabled *= *true|minifyEnabled *true|proguardFiles|Base64|ZipInputStream|Cipher|SecretKeySpec' \
  "No obfuscation, minification, encoded payloads or crypto helpers. Source is plain Kotlin."
check "Background work frameworks" \
  'JobScheduler|JobService|WorkManager|AlarmManager|SyncAdapter|JobIntentService|BIND_JOB_SERVICE' \
  "No job/alarm/work scheduling; monitoring is event driven."
check "Writes to system settings" \
  'Settings\.(Secure|System|Global)\.put|WRITE_SECURE_SETTINGS|WRITE_SETTINGS|putStringForUser|ENABLED_ACCESSIBILITY_SERVICES *, *[a-z]' \
  "Settings.Secure is only READ; no write permission is declared."
check "Shizuku / root" 'rikka|shizuku|su -c|/system/xbin/su|libsu|topjohnwu' "No Shizuku or root code."
check "VPN" 'VpnService|BIND_VPN_SERVICE|VpnManager' "No VPN code."
check "Device Admin / Device Owner / kiosk" \
  'DeviceAdminReceiver|BIND_DEVICE_ADMIN|DevicePolicyManager|device_admin|setLockTaskPackages|startLockTask|DeviceOwner' \
  "No Device Admin, Device Owner or lock-task code."
check "Watchdog implements an AccessibilityService" \
  'BIND_ACCESSIBILITY_SERVICE|: *AccessibilityService *\(|extends +AccessibilityService|accessibility-service|AccessibilityEvent' \
  "The watchdog is not an Accessibility Service (it only reads the system setting)."
check "Silent installs / package changes" \
  'REQUEST_INSTALL_PACKAGES|INSTALL_PACKAGES|DELETE_PACKAGES|REQUEST_DELETE_PACKAGES|QUERY_ALL_PACKAGES' \
  "No install/uninstall or broad package-listing permission."

# ---- Permission allow-list --------------------------------------------------------------
ALLOWED="SYSTEM_ALERT_WINDOW FOREGROUND_SERVICE FOREGROUND_SERVICE_SPECIAL_USE POST_NOTIFICATIONS RECEIVE_BOOT_COMPLETED PACKAGE_USAGE_STATS"
declared=$(grep -oE 'android\.permission\.[A-Z_]+' "$MANIFEST" | sed 's/android\.permission\.//' | sort -u)
extra=""
for p in $declared; do
  case " $ALLOWED " in *" $p "*) ;; *) extra="$extra $p" ;; esac
done
if [ -z "$extra" ]; then
  echo "| Suspicious / unexpected permissions | No | Exactly these are declared: $(echo $declared | tr ' ' ',') (all explained in README). |"
else
  fail=1
  echo "| Suspicious / unexpected permissions | **YES** | Unexpected:$extra |"
fi

# ---- Components ---------------------------------------------------------------------------
svc=$(grep -c '<service' "$MANIFEST" || true)
rcv=$(grep -c '<receiver' "$MANIFEST" || true)
prv=$(grep -c '<provider' "$MANIFEST" || true)
if [ "$svc" = "1" ] && [ "$rcv" = "1" ] && [ "$prv" = "0" ]; then
  echo "| Unnecessary background services | No | Exactly 1 foreground service (the watcher) and 1 boot receiver; 0 content providers. |"
else
  fail=1
  echo "| Unnecessary background services | **YES** | services=$svc receivers=$rcv providers=$prv (expected 1/1/0) |"
fi

# ---- Dependencies -------------------------------------------------------------------------
if grep -qE '^\s*(implementation|api|compileOnly|runtimeOnly|kapt|ksp)\s*[(\"]' app/build.gradle.kts; then
  fail=1
  echo "| Third-party dependencies | **YES** | app/build.gradle.kts declares dependencies; review them. |"
else
  echo "| Third-party dependencies | No | app/build.gradle.kts has no dependencies block (platform APIs only). |"
fi

echo
if [ "$fail" -eq 0 ]; then echo "AUDIT RESULT: PASS"; else echo "AUDIT RESULT: FAIL"; fi
exit "$fail"
