package com.example.accessibilitywatchdog

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.database.ContentObserver
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.util.Log

/**
 * Foreground service that watches the system Accessibility setting.
 *
 * Detection is event driven: a ContentObserver on Settings.Secure fires when the setting
 * changes. It is re-checked on screen on / unlock / app resume. There is NO periodic polling
 * while the protection is active. (A 500 ms tick runs only during the short "user is in
 * Settings" window described below.)
 *
 * States:
 *  OK             - selected service is ON. Nothing is shown.
 *  BLOCKING       - service is OFF. Full-screen warning is shown.
 *  SETTINGS_GRACE - user pressed OPEN ACCESSIBILITY SETTINGS. The warning is REMOVED so that
 *                   Settings is fully usable. The warning comes back as soon as the user
 *                   leaves Settings (requires Usage access), returns to this app, turns
 *                   the screen off, or a timeout expires, unless the service is ON by then.
 */
class WatchdogService : Service() {

    private enum class Mode { OK, BLOCKING, SETTINGS_GRACE }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var overlay: WarningOverlay
    private lateinit var notificationManager: NotificationManager

    private var mode = Mode.OK
    private var testActive = false

    // SETTINGS_GRACE bookkeeping
    private var graceStartMs = 0L
    private var usageQueryFromMs = 0L
    private var lastForeground: String? = null
    private var sawForegroundEvent = false
    private var allowedPackages: Set<String> = emptySet()

    private var lastOngoingText: String? = null

    private val settingsObserver = object : ContentObserver(handler) {
        override fun onChange(selfChange: Boolean) {
            evaluate()
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    // Leaving the grace window: the warning must be waiting after screen-on.
                    if (mode == Mode.SETTINGS_GRACE) mode = Mode.OK
                    evaluate()
                }
                Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT -> evaluate()
            }
        }
    }

    private val graceTick = object : Runnable {
        override fun run() {
            if (mode != Mode.SETTINGS_GRACE) return
            evaluate()
            if (mode == Mode.SETTINGS_GRACE) handler.postDelayed(this, TICK_MS)
        }
    }

    private val testTimeout = Runnable { endTest() }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(NotificationManager::class.java)
        createChannels()
        startAsForeground(
            buildNotification(CHANNEL_STATUS, getString(R.string.notif_starting), ongoing = true)
        )
        overlay = WarningOverlay(this)

        contentResolver.registerContentObserver(
            Settings.Secure.getUriFor(Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES),
            false, settingsObserver
        )
        contentResolver.registerContentObserver(
            Settings.Secure.getUriFor(Settings.Secure.ACCESSIBILITY_ENABLED),
            false, settingsObserver
        )

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(screenReceiver, filter)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Prefs.getTarget(this) == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        when (intent?.action) {
            ACTION_TEST -> startTest()
            ACTION_APP_RESUMED -> {
                // The user came back to the watchdog: if they were in the Settings grace
                // window, it is over. evaluate() below re-blocks if the service is still OFF.
                if (mode == Mode.SETTINGS_GRACE) mode = Mode.OK
            }
        }
        evaluate()
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        contentResolver.unregisterContentObserver(settingsObserver)
        try {
            unregisterReceiver(screenReceiver)
        } catch (e: IllegalArgumentException) {
            // already unregistered
        }
        overlay.hide()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ---------------------------------------------------------------- core logic

    private fun evaluate() {
        val target = Prefs.getTarget(this)
        if (target == null) {
            stopSelf()
            return
        }

        if (AccessibilityState.isEnabled(this, target)) {
            leaveToOk(target)
            return
        }

        // Service is OFF. A real warning always replaces a running test.
        if (testActive) endTest()
        when (mode) {
            Mode.OK -> enterBlocking(target)
            Mode.BLOCKING -> showBlockingOverlay(target)
            Mode.SETTINGS_GRACE -> checkGrace(target)
        }
        updateOngoing(target)
    }

    private fun leaveToOk(target: ComponentName) {
        handler.removeCallbacks(graceTick)
        mode = Mode.OK
        if (!testActive) overlay.hide()
        notificationManager.cancel(ALERT_ID)
        updateOngoing(target)
    }

    private fun enterBlocking(target: ComponentName) {
        handler.removeCallbacks(graceTick)
        mode = Mode.BLOCKING
        showBlockingOverlay(target)
    }

    private fun showBlockingOverlay(target: ComponentName) {
        if (!Settings.canDrawOverlays(this)) {
            // Cannot block without the permission: say so loudly instead of failing silently.
            notificationManager.notify(
                ALERT_ID,
                buildNotification(
                    CHANNEL_ALERT, getString(R.string.notif_overlay_missing), ongoing = false
                )
            )
            return
        }
        notificationManager.cancel(ALERT_ID)
        overlay.show(
            serviceDescription = describeTarget(target),
            testMode = false,
            onOpenSettings = { onOpenSettingsPressed() },
            onEndTest = { endTest() }
        )
    }

    /** Button on the overlay. Opens Settings and gets the overlay out of the way. */
    private fun onOpenSettingsPressed() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            // Started while our overlay window is still visible (allowed background start).
            startActivity(intent)
        } catch (e: RuntimeException) {
            Log.w(TAG, "Could not open Accessibility Settings", e)
            return
        }

        if (testActive) {
            endTest()
            return
        }
        val target = Prefs.getTarget(this) ?: return

        mode = Mode.SETTINGS_GRACE
        graceStartMs = SystemClock.elapsedRealtime()
        usageQueryFromMs = System.currentTimeMillis() - 200
        lastForeground = null
        sawForegroundEvent = false
        allowedPackages = buildAllowedPackages(target)

        // Remove EVERY overlay window: Settings ignores touches on its sensitive screens
        // while any overlay is above it, which would stop the user from enabling the service.
        overlay.hide()
        handler.removeCallbacks(graceTick)
        handler.postDelayed(graceTick, TICK_MS)
        updateOngoing(target)
    }

    private fun checkGrace(target: ComponentName) {
        val elapsed = SystemClock.elapsedRealtime() - graceStartMs
        if (elapsed > GRACE_MAX_MS) {
            enterBlocking(target)
            return
        }

        if (UsageAccess.isGranted(this)) {
            pollForeground()
            if (sawForegroundEvent) {
                val foreground = lastForeground
                if (elapsed > START_ALLOWANCE_MS &&
                    foreground != null &&
                    foreground !in allowedPackages
                ) {
                    // The user left Settings without enabling the service.
                    enterBlocking(target)
                }
                return
            }
        }

        // Usage access is mandatory for the Settings grace window. If it is revoked,
        // do not silently fall back to a long timer: keep the grace state until Android
        // reports that the user left Settings, or until the service is re-evaluated.
        // The setup screen tells the user that Usage access is required.
    }

    @Suppress("DEPRECATION")
    private fun pollForeground() {
        val usageStats = getSystemService(UsageStatsManager::class.java) ?: return
        val now = System.currentTimeMillis()
        val events: UsageEvents? = try {
            usageStats.queryEvents(usageQueryFromMs, now)
        } catch (e: SecurityException) {
            null
        }
        if (events == null) return

        val event = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                lastForeground = event.packageName
                sawForegroundEvent = true
            }
        }
        usageQueryFromMs = now - 1000
    }

    @Suppress("DEPRECATION")
    private fun buildAllowedPackages(target: ComponentName): Set<String> {
        val packages = hashSetOf(
            "com.android.settings",
            "com.android.systemui",
            "android",
            "com.google.android.permissioncontroller",
            "com.android.permissioncontroller",
            target.packageName
        )
        val resolved = packageManager.resolveActivity(
            Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS), PackageManager.MATCH_DEFAULT_ONLY
        )
        resolved?.activityInfo?.packageName?.let { packages.add(it) }
        return packages
    }

    // ---------------------------------------------------------------- test mode

    private fun startTest() {
        if (mode != Mode.OK || testActive) return
        if (!Settings.canDrawOverlays(this)) return
        val target = Prefs.getTarget(this) ?: return
        testActive = true
        val shown = overlay.show(
            serviceDescription = describeTarget(target),
            testMode = true,
            onOpenSettings = { onOpenSettingsPressed() },
            onEndTest = { endTest() }
        )
        if (shown) {
            handler.postDelayed(testTimeout, TEST_TIMEOUT_MS)
        } else {
            testActive = false
        }
    }

    private fun endTest() {
        if (!testActive) return
        testActive = false
        handler.removeCallbacks(testTimeout)
        overlay.hide()
    }

    // ---------------------------------------------------------------- notifications

    private fun describeTarget(target: ComponentName): String {
        val entry = ServiceCatalog.describe(this, target)
        val name = entry?.serviceLabel ?: target.shortClassName
        return getString(R.string.overlay_service, name, target.packageName)
    }

    private fun updateOngoing(target: ComponentName) {
        val text = when (mode) {
            Mode.OK -> getString(
                R.string.notif_ok,
                ServiceCatalog.describe(this, target)?.serviceLabel ?: target.packageName
            )
            Mode.BLOCKING -> getString(R.string.notif_off)
            Mode.SETTINGS_GRACE -> getString(R.string.notif_grace)
        }
        if (text == lastOngoingText) return
        lastOngoingText = text
        notificationManager.notify(
            NOTIF_ID, buildNotification(CHANNEL_STATUS, text, ongoing = true)
        )
    }

    private fun createChannels() {
        val status = NotificationChannel(
            CHANNEL_STATUS,
            getString(R.string.channel_status_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.channel_status_desc)
            setShowBadge(false)
        }
        val alert = NotificationChannel(
            CHANNEL_ALERT,
            getString(R.string.channel_alert_name),
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = getString(R.string.channel_alert_desc)
        }
        notificationManager.createNotificationChannels(listOf(status, alert))
    }

    private fun buildNotification(channel: String, text: String, ongoing: Boolean): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, channel)
            .setSmallIcon(R.drawable.ic_stat_watchdog)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setOngoing(ongoing)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .build()
    }

    private fun startAsForeground(notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    companion object {
        const val ACTION_TEST = "com.example.accessibilitywatchdog.action.TEST"
        const val ACTION_APP_RESUMED = "com.example.accessibilitywatchdog.action.APP_RESUMED"

        private const val TAG = "WatchdogService"
        private const val CHANNEL_STATUS = "watchdog_status"
        private const val CHANNEL_ALERT = "watchdog_alert"
        private const val NOTIF_ID = 11
        private const val ALERT_ID = 12

        private const val TICK_MS = 500L
        private const val START_ALLOWANCE_MS = 3_000L
        private const val GRACE_MAX_MS = 600_000L
        private const val TEST_TIMEOUT_MS = 10_000L

        /** Starts (or pings) the service. Does nothing until a service has been selected. */
        fun start(context: Context, action: String? = null) {
            if (Prefs.getTarget(context) == null) return
            val intent = Intent(context, WatchdogService::class.java).setAction(action)
            try {
                context.startForegroundService(intent)
            } catch (e: RuntimeException) {
                // e.g. the OS refused a background foreground-service start
                Log.w(TAG, "Could not start watchdog service", e)
            }
        }
    }
}
