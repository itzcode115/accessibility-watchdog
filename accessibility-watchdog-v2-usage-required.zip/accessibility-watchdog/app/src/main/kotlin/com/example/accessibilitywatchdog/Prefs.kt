package com.example.accessibilitywatchdog

import android.content.ComponentName
import android.content.Context

/**
 * The ONLY thing this app stores: the flattened ComponentName ("package/class") of the
 * Accessibility Service the user chose to monitor. Kept in app-private storage.
 */
object Prefs {
    private const val FILE = "watchdog"
    private const val KEY_TARGET = "target_component"

    fun getTarget(context: Context): ComponentName? {
        val raw = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getString(KEY_TARGET, null)
        return if (raw.isNullOrEmpty()) null else ComponentName.unflattenFromString(raw)
    }

    fun setTarget(context: Context, target: ComponentName) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_TARGET, target.flattenToString())
            .apply()
    }
}
