package com.example.accessibilitywatchdog

import android.content.ComponentName
import android.content.Context
import android.provider.Settings

/** Read-only view of the system's Accessibility settings. This app NEVER writes them. */
object AccessibilityState {

    /**
     * True only if accessibility is globally enabled AND [target] is listed in
     * Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES.
     *
     * Entries are compared as parsed ComponentNames, because different Android versions /
     * OEMs write either "pkg/pkg.Cls" or the short form "pkg/.Cls".
     */
    fun isEnabled(context: Context, target: ComponentName): Boolean {
        val resolver = context.contentResolver
        val master = Settings.Secure.getInt(resolver, Settings.Secure.ACCESSIBILITY_ENABLED, 0)
        if (master != 1) return false

        val raw = Settings.Secure.getString(
            resolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false

        return raw.split(':').any { entry ->
            val parsed = ComponentName.unflattenFromString(entry.trim())
            parsed != null && parsed == target
        }
    }
}
