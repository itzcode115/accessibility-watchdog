package com.example.accessibilitywatchdog

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var intro: TextView
    private lateinit var status: TextView
    private lateinit var monitoredGroup: View
    private lateinit var serviceName: TextView
    private lateinit var serviceApp: TextView
    private lateinit var servicePackage: TextView
    private lateinit var btnChange: Button
    private lateinit var btnTest: Button
    private lateinit var setupOverlay: TextView
    private lateinit var btnOverlay: Button
    private lateinit var setupNotif: TextView
    private lateinit var btnNotif: Button
    private lateinit var setupUsage: TextView
    private lateinit var btnUsage: Button

    private val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            refresh()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        intro = findViewById(R.id.intro)
        status = findViewById(R.id.status)
        monitoredGroup = findViewById(R.id.monitoredGroup)
        serviceName = findViewById(R.id.serviceName)
        serviceApp = findViewById(R.id.serviceApp)
        servicePackage = findViewById(R.id.servicePackage)
        btnChange = findViewById(R.id.btnChange)
        btnTest = findViewById(R.id.btnTest)
        setupOverlay = findViewById(R.id.setupOverlay)
        btnOverlay = findViewById(R.id.btnOverlay)
        setupNotif = findViewById(R.id.setupNotif)
        btnNotif = findViewById(R.id.btnNotif)
        setupUsage = findViewById(R.id.setupUsage)
        btnUsage = findViewById(R.id.btnUsage)

        btnChange.setOnClickListener {
            startActivity(Intent(this, PickerActivity::class.java))
        }
        btnTest.setOnClickListener { onTestClicked() }
        findViewById<Button>(R.id.btnSettings).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } catch (e: RuntimeException) {
                Toast.makeText(this, R.string.no_settings_toast, Toast.LENGTH_LONG).show()
            }
        }
        btnOverlay.setOnClickListener { openOverlayPermissionPage() }
        btnNotif.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            }
        }
        btnUsage.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            } catch (e: RuntimeException) {
                Toast.makeText(this, R.string.no_settings_toast, Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onStart() {
        super.onStart()
        contentResolver.registerContentObserver(
            Settings.Secure.getUriFor(Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES),
            false, observer
        )
        contentResolver.registerContentObserver(
            Settings.Secure.getUriFor(Settings.Secure.ACCESSIBILITY_ENABLED),
            false, observer
        )
    }

    override fun onResume() {
        super.onResume()
        refresh()
        // Re-check immediately whenever the user comes back to the watchdog.
        WatchdogService.start(this, WatchdogService.ACTION_APP_RESUMED)
    }

    override fun onStop() {
        contentResolver.unregisterContentObserver(observer)
        super.onStop()
    }

    private fun refresh() {
        val target = Prefs.getTarget(this)
        val hasTarget = target != null

        intro.visibility = if (hasTarget) View.GONE else View.VISIBLE
        monitoredGroup.visibility = if (hasTarget) View.VISIBLE else View.GONE
        btnTest.visibility = if (hasTarget) View.VISIBLE else View.GONE
        btnChange.setText(if (hasTarget) R.string.btn_change else R.string.btn_choose)

        if (target == null) {
            status.setText(R.string.status_none)
            status.setTextColor(getColor(R.color.gray))
        } else {
            val on = AccessibilityState.isEnabled(this, target)
            status.setText(if (on) R.string.status_on else R.string.status_off)
            status.setTextColor(getColor(if (on) R.color.green else R.color.red))

            val entry = ServiceCatalog.describe(this, target)
            serviceName.text = entry?.serviceLabel ?: getString(R.string.service_not_installed)
            serviceApp.text = getString(R.string.app_line, entry?.appLabel ?: target.packageName)
            servicePackage.text = target.packageName + "\n" + target.className
        }

        val overlayOk = Settings.canDrawOverlays(this)
        setupOverlay.setText(if (overlayOk) R.string.setup_overlay_ok else R.string.setup_overlay_missing)
        btnOverlay.visibility = if (overlayOk) View.GONE else View.VISIBLE

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val notifOk = checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
            setupNotif.visibility = View.VISIBLE
            setupNotif.setText(if (notifOk) R.string.setup_notif_ok else R.string.setup_notif_missing)
            btnNotif.visibility = if (notifOk) View.GONE else View.VISIBLE
        } else {
            setupNotif.visibility = View.GONE
            btnNotif.visibility = View.GONE
        }

        val usageOk = UsageAccess.isGranted(this)
        setupUsage.setText(if (usageOk) R.string.setup_usage_ok else R.string.setup_usage_missing)
        btnUsage.visibility = if (usageOk) View.GONE else View.VISIBLE
    }

    private fun onTestClicked() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.need_overlay_toast, Toast.LENGTH_LONG).show()
            openOverlayPermissionPage()
            return
        }
        WatchdogService.start(this, WatchdogService.ACTION_TEST)
    }

    private fun openOverlayPermissionPage() {
        try {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        } catch (e: RuntimeException) {
            Toast.makeText(this, R.string.no_settings_toast, Toast.LENGTH_LONG).show()
        }
    }

    private companion object {
        const val REQ_NOTIF = 1
    }
}
