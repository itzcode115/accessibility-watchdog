package com.example.accessibilitywatchdog

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.view.accessibility.AccessibilityManager

/** What the user sees for one installed Accessibility Service. */
data class ServiceEntry(
    val component: ComponentName,
    val appLabel: String,
    val serviceLabel: String
)

/**
 * Lists installed Accessibility Services. Using AccessibilityManager to *list* services does
 * not make this app an Accessibility Service and needs no Accessibility permission.
 */
object ServiceCatalog {

    fun installed(context: Context): List<ServiceEntry> {
        val pm = context.packageManager
        val manager = context.getSystemService(AccessibilityManager::class.java) ?: return emptyList()
        return manager.installedAccessibilityServiceList
            .mapNotNull { info -> info.resolveInfo?.serviceInfo }
            .map { toEntry(pm, it) }
            .distinctBy { it.component }
            .sortedBy { it.appLabel.lowercase() }
    }

    /** Looks up the label of a previously chosen service, or null if it is not installed. */
    fun describe(context: Context, component: ComponentName): ServiceEntry? {
        val pm = context.packageManager
        return try {
            toEntry(pm, pm.getServiceInfo(component, 0))
        } catch (e: PackageManager.NameNotFoundException) {
            null
        }
    }

    private fun toEntry(pm: PackageManager, info: ServiceInfo): ServiceEntry {
        val appLabel = info.applicationInfo?.loadLabel(pm)?.toString() ?: info.packageName
        val serviceLabel = info.loadLabel(pm).toString()
        return ServiceEntry(ComponentName(info.packageName, info.name), appLabel, serviceLabel)
    }
}
