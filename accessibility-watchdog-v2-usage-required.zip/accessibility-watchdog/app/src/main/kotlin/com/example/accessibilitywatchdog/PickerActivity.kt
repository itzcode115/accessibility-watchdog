package com.example.accessibilitywatchdog

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

/** Lists every installed Accessibility Service (app name, service name, package). */
class PickerActivity : Activity() {

    private lateinit var entries: List<ServiceEntry>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_picker)

        entries = ServiceCatalog.installed(this)
        val current = Prefs.getTarget(this)

        val list = findViewById<ListView>(R.id.serviceList)
        list.emptyView = findViewById<View>(R.id.emptyText)
        list.adapter = ServiceAdapter(current)
        list.setOnItemClickListener { _, _, position, _ -> confirm(entries[position]) }
    }

    private fun confirm(entry: ServiceEntry) {
        AlertDialog.Builder(this)
            .setTitle(R.string.confirm_title)
            .setMessage(
                getString(
                    R.string.confirm_message,
                    entry.serviceLabel, entry.appLabel, entry.component.packageName
                )
            )
            .setPositiveButton(R.string.confirm_yes) { _, _ -> save(entry) }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun save(entry: ServiceEntry) {
        Prefs.setTarget(this, entry.component)
        WatchdogService.start(this)
        Toast.makeText(
            this, getString(R.string.saved_toast, entry.serviceLabel), Toast.LENGTH_LONG
        ).show()
        finish()
    }

    private inner class ServiceAdapter(
        private val current: android.content.ComponentName?
    ) : BaseAdapter() {

        override fun getCount(): Int = entries.size
        override fun getItem(position: Int): Any = entries[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = convertView
                ?: LayoutInflater.from(this@PickerActivity)
                    .inflate(R.layout.item_service, parent, false)
            val entry = entries[position]
            row.findViewById<TextView>(R.id.itemApp).text = entry.appLabel
            row.findViewById<TextView>(R.id.itemService).text =
                getString(R.string.picker_service_line, entry.serviceLabel)
            row.findViewById<TextView>(R.id.itemPackage).text =
                getString(R.string.picker_package_line, entry.component.packageName)
            row.findViewById<View>(R.id.itemCurrent).visibility =
                if (entry.component == current) View.VISIBLE else View.GONE
            return row
        }
    }
}
