package com.example.accessibilitywatchdog

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Restarts monitoring after a reboot (once the user has unlocked the phone) and after this
 * app is updated. It grants nothing and changes no settings. Note: Android does not deliver
 * this broadcast to an app that was force-stopped until the user opens it again.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED -> WatchdogService.start(context)
        }
    }
}
