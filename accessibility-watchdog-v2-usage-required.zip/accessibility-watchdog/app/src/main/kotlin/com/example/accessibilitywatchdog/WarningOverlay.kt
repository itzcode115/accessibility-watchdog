package com.example.accessibilitywatchdog

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.util.Log
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView

/** Root of the overlay window. Swallows Back so it cannot act on the app underneath. */
private class OverlayRoot(context: Context) : FrameLayout(context) {
    override fun dispatchKeyEvent(event: KeyEvent): Boolean =
        if (event.keyCode == KeyEvent.KEYCODE_BACK) true else super.dispatchKeyEvent(event)
}

/**
 * The full-screen warning. It is a normal TYPE_APPLICATION_OVERLAY window (needs the
 * "Display over other apps" permission). It cannot cover the status bar / notification shade
 * or the lock screen; that is an Android restriction, not something this app can change.
 */
class WarningOverlay(private val context: Context) {

    private val windowManager = context.getSystemService(WindowManager::class.java)
    private var root: View? = null

    fun isShowing(): Boolean = root != null

    /** Returns true if the overlay is on screen after the call. */
    fun show(
        serviceDescription: String,
        testMode: Boolean,
        onOpenSettings: () -> Unit,
        onEndTest: () -> Unit
    ): Boolean {
        if (root != null) return true

        val themed = ContextThemeWrapper(context, R.style.AppTheme)
        val container = OverlayRoot(themed)
        LayoutInflater.from(themed).inflate(R.layout.overlay_warning, container, true)

        container.findViewById<TextView>(R.id.overlayService).text = serviceDescription
        container.findViewById<Button>(R.id.overlayOpenSettings)
            .setOnClickListener { onOpenSettings() }

        if (testMode) {
            container.findViewById<View>(R.id.overlayTestBanner).visibility = View.VISIBLE
            container.findViewById<Button>(R.id.overlayEndTest).apply {
                visibility = View.VISIBLE
                setOnClickListener { onEndTest() }
            }
        }

        val params = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            title = "Accessibility Watchdog warning"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        return try {
            windowManager.addView(container, params)
            root = container
            true
        } catch (e: Exception) {
            // Typically: overlay permission revoked, or the OEM blocks overlays.
            Log.w(TAG, "Could not add overlay window", e)
            false
        }
    }

    fun hide() {
        val view = root ?: return
        root = null
        try {
            windowManager.removeViewImmediate(view)
        } catch (e: Exception) {
            Log.w(TAG, "Could not remove overlay window", e)
        }
    }

    private companion object {
        const val TAG = "WatchdogOverlay"
    }
}
